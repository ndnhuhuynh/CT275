<footer class="footer">
	<div class="container text-center">
		<p class="text-muted">Copyright &copy; 2022 Web Development Course</p>
	</div>
</footer>